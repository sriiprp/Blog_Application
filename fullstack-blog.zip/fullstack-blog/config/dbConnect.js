const mongoose = require('mongoose');
const dbConnect = async()=>{
    
    try{
        await mongoose.connect('mongodb+srv://sriiniti:cmgRmQSZEivjEnHj@fullstack-blog-applicti.fl0f2su.mongodb.net/fullstack-blog?retryWrites=true&w=majority');
        console.log('DB Connected Successfully');

    }
    catch(error){
        console.log("DB Connection Failed ",error.message);

    }
};
dbConnect();
